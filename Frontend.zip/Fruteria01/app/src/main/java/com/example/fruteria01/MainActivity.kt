package com.example.fruteria01

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val btnInventario : Button = findViewById(R.id.btnInventario)
        val btnRegistroVentas : Button = findViewById(R.id.btnRegistroVentas)
        val btnNotificaciones : Button = findViewById(R.id.btnNotificaciones)
        val btnPerfil : Button = findViewById(R.id.btnPerfil)
        val btnConfiguracion : Button = findViewById(R.id.btnConfiguracion)


        btnInventario.setOnClickListener(View.OnClickListener {
            val inInv : Intent = Intent(this, InventarioActivity::class.java)
            startActivity(inInv)
        })

        btnRegistroVentas.setOnClickListener(View.OnClickListener {
            val inRegVen : Intent = Intent(this, RegistroVentasActivity::class.java)
            startActivity(inRegVen)
        })

        btnNotificaciones.setOnClickListener(View.OnClickListener {
            val inNot : Intent = Intent(this, NotificacionesActivity::class.java)
            startActivity(inNot)
        })

        btnPerfil.setOnClickListener(View.OnClickListener {
            val inPer : Intent = Intent(this, PerfilActivity::class.java)
            startActivity(inPer)
        })

        btnConfiguracion.setOnClickListener(View.OnClickListener {
            val inConf : Intent = Intent(this, ConfiguracionActivity::class.java)
            startActivity(inConf)
        })
    }


}

