package com.example.fruteria01.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListView
import androidx.fragment.app.Fragment
import com.example.fruteria01.R
import com.example.fruteria01.model.Inventario
import com.example.fruteria01.adapter.InventarioAdapter

class ListaInventarioFragment : Fragment() {

    private lateinit var listView: ListView

    private val inventarioList = listOf(
        Inventario(R.drawable.manzana, "Producto 1", "2024-12-31", "Alimentos", 10.99),
        Inventario(R.drawable.manzana, "Producto 2", "2025-01-15", "Bebidas", 5.49),
        Inventario(R.drawable.manzana, "Producto 3", "2024-06-01", "Alimentos", 15.00)
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView = inflater.inflate(R.layout.fragment_lista_inventario, container, false)

        listView = rootView.findViewById(R.id.listViewInventario)

        val adaptador = InventarioAdapter(requireContext(), inventarioList)
        listView.adapter = adaptador

        return rootView
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            ListaInventarioFragment().apply {
                arguments = Bundle().apply {
                    putString("param1", param1)
                    putString("param2", param2)
                }
            }
    }
}
