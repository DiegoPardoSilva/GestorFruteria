package com.example.fruteria01

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class ConfiguracionActivity : AppCompatActivity() {


        private lateinit var drawerLayout: DrawerLayout

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_configuracion)

            drawerLayout = findViewById(R.id.drawer_layout)

            val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar_main)
            setSupportActionBar(toolbar)

            // Configurar el botón de la toolbar para abrir el Navigation Drawer
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
            supportActionBar?.setHomeAsUpIndicator(R.drawable.navigator_menu_logo)

            // Configurar la NavigationView para navegar con Intents
            val navigationView: NavigationView = findViewById(R.id.nav_view)
            navigationView.setNavigationItemSelectedListener { menuItem ->
                when (menuItem.itemId) {
                    R.id.nav_inventario -> {
                        val intent = Intent(this, InventarioActivity::class.java)
                        startActivity(intent)
                    }
                    R.id.nav_registro_ventas -> {
                        val intent = Intent(this, RegistroVentasActivity::class.java)
                        startActivity(intent)
                    }
                    R.id.nav_notificaciones -> {
                        val intent = Intent(this, NotificacionesActivity::class.java)
                        startActivity(intent)
                    }
                    R.id.nav_perfil -> {
                        val intent = Intent(this, PerfilActivity::class.java)
                        startActivity(intent)
                    }
                    R.id.nav_configuracion -> {
                        drawerLayout.closeDrawers()
                    }
                }
                drawerLayout.closeDrawers()
                true
            }
        }

        override fun onOptionsItemSelected(item: MenuItem): Boolean {
            return when (item.itemId) {
                android.R.id.home -> {
                    drawerLayout.openDrawer(GravityCompat.START)
                    true
                }
                else -> super.onOptionsItemSelected(item)
            }
        }
    }
