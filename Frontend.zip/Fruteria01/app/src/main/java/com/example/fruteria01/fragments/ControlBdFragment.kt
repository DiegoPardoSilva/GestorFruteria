package com.example.fruteria01.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.fruteria01.R
import com.example.fruteria01.model.Inventario
import com.example.fruteria01.adapter.InventarioAdapter

class ControlBdFragment : Fragment() {

    private lateinit var editTextNombre: EditText
    private lateinit var editTextTipo: EditText
    private lateinit var editTextPrecio: EditText
    private lateinit var editTextFechaCaducidad: EditText
    private lateinit var listViewProductos: ListView

    private val inventarioList = mutableListOf<Inventario>()
    private var productoSeleccionado: Inventario? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView = inflater.inflate(R.layout.fragment_control_bd, container, false)

        editTextNombre = rootView.findViewById(R.id.etNombre)
        editTextTipo = rootView.findViewById(R.id.etTipo)
        editTextPrecio = rootView.findViewById(R.id.etPrecio)
        editTextFechaCaducidad = rootView.findViewById(R.id.etFechaCaducidad)
        listViewProductos = rootView.findViewById(R.id.lvProductos)

        val buttonCrear: Button = rootView.findViewById(R.id.btnCrear)
        val buttonActualizar: Button = rootView.findViewById(R.id.btnActualizar)
        val buttonEliminar: Button = rootView.findViewById(R.id.btnEliminar)

        val adaptador = InventarioAdapter(requireContext(), inventarioList)
        listViewProductos.adapter = adaptador

        buttonCrear.setOnClickListener { crearProducto() }
        buttonActualizar.setOnClickListener { actualizarProducto() }
        buttonEliminar.setOnClickListener { eliminarProducto() }

        listViewProductos.setOnItemClickListener { _, _, position, _ ->
            productoSeleccionado = inventarioList[position]
            llenarCamposConProductoSeleccionado()
        }

        return rootView
    }

    private fun crearProducto() {
        val nombre = editTextNombre.text.toString()
        val tipo = editTextTipo.text.toString()
        val precio = editTextPrecio.text.toString().toDoubleOrNull()
        val fechaCaducidad = editTextFechaCaducidad.text.toString()

        if (nombre.isNotEmpty() && tipo.isNotEmpty() && precio != null && fechaCaducidad.isNotEmpty()) {
            val nuevoProducto = Inventario(R.drawable.manzana, nombre, fechaCaducidad, tipo, precio)
            inventarioList.add(nuevoProducto)
            (listViewProductos.adapter as InventarioAdapter).notifyDataSetChanged()
            limpiarCampos()
            Toast.makeText(requireContext(), "Producto creado", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(requireContext(), "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show()
        }
    }

    private fun actualizarProducto() {
        val nombre = editTextNombre.text.toString()
        val tipo = editTextTipo.text.toString()
        val precio = editTextPrecio.text.toString().toDoubleOrNull()
        val fechaCaducidad = editTextFechaCaducidad.text.toString()

        val producto = productoSeleccionado
        if (producto != null && nombre.isNotEmpty() && tipo.isNotEmpty() && precio != null && fechaCaducidad.isNotEmpty()) {
            producto.nombre = nombre
            producto.tipo = tipo
            producto.precio = precio
            producto.fechaCaducidad = fechaCaducidad

            (listViewProductos.adapter as InventarioAdapter).notifyDataSetChanged()
            limpiarCampos()
            productoSeleccionado = null
            Toast.makeText(requireContext(), "Producto actualizado", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(requireContext(), "Por favor, complete todos los campos y seleccione un producto", Toast.LENGTH_SHORT).show()
        }
    }

    private fun eliminarProducto() {
        val producto = productoSeleccionado
        if (producto != null) {
            inventarioList.remove(producto)
            (listViewProductos.adapter as InventarioAdapter).notifyDataSetChanged()
            limpiarCampos()
            productoSeleccionado = null
            Toast.makeText(requireContext(), "Producto eliminado", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(requireContext(), "Por favor, seleccione un producto para eliminar", Toast.LENGTH_SHORT).show()
        }
    }

    private fun llenarCamposConProductoSeleccionado() {
        val producto = productoSeleccionado
        if (producto != null) {
            editTextNombre.setText(producto.nombre)
            editTextTipo.setText(producto.tipo)
            editTextPrecio.setText(producto.precio.toString())
            editTextFechaCaducidad.setText(producto.fechaCaducidad)
        }
    }

    private fun limpiarCampos() {
        editTextNombre.text.clear()
        editTextTipo.text.clear()
        editTextPrecio.text.clear()
        editTextFechaCaducidad.text.clear()
    }
}
