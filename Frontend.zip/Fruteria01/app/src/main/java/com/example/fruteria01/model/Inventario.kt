package com.example.fruteria01.model

data class Inventario(
    val imagenResId: Int,
    var nombre: String,
    var fechaCaducidad: String,
    var tipo: String,
    var precio: Double
)
