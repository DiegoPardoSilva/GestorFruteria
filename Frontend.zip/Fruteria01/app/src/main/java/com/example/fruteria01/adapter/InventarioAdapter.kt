package com.example.fruteria01.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.fruteria01.R
import com.example.fruteria01.model.Inventario


class InventarioAdapter(context: Context, private val inventarioList: List<Inventario>) : BaseAdapter() {

    private val inflater: LayoutInflater = LayoutInflater.from(context)

    override fun getCount(): Int {
        return inventarioList.size
    }

    override fun getItem(position: Int): Any {
        return inventarioList[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        // Inflar el layout de cada ítem
        val view: View = convertView ?: inflater.inflate(R.layout.lista_inventario, parent, false)

        // Obtener el ítem actual
        val item = inventarioList[position]

        // Referencias a los elementos de la vista
        val imageView = view.findViewById<ImageView>(R.id.imageViewProducto)
        val textViewNombre = view.findViewById<TextView>(R.id.textViewNombre)
        val textViewFechaCaducidad = view.findViewById<TextView>(R.id.textViewFechaCaducidad)
        val textViewTipo = view.findViewById<TextView>(R.id.textViewTipo)
        val textViewPrecio = view.findViewById<TextView>(R.id.textViewPrecio)

        // Establecer los valores en los TextViews e ImageView
        imageView.setImageResource(item.imagenResId)
        textViewNombre.text = item.nombre
        textViewFechaCaducidad.text = item.fechaCaducidad
        textViewTipo.text = item.tipo
        textViewPrecio.text = "$${item.precio}"

        return view
    }
}
