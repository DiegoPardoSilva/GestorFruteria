package com.example.fruteria01

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class InicioSesion : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inicio_sesion)
    }
}