package com.example.fruteria01

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class PerfilActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil)

        drawerLayout = findViewById(R.id.drawer_layout)

        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar_main)
        setSupportActionBar(toolbar)

        // Configurar el botón de la toolbar para abrir el Navigation Drawer
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.navigator_menu_logo) // Reemplaza con tu ícono de menú

        // Configurar la NavigationView para navegar con Intents
        val navigationView: NavigationView = findViewById(R.id.nav_view)
        navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_inventario -> {
                    // Navegar a Activity1
                    val intent = Intent(this, InventarioActivity::class.java)
                    startActivity(intent)
                }
                R.id.nav_registro_ventas -> {
                    // Navegar a Activity3
                    val intent = Intent(this, RegistroVentasActivity::class.java)
                    startActivity(intent)
                }
                R.id.nav_notificaciones -> {
                    // Navegar a Activity3
                    val intent = Intent(this, NotificacionesActivity::class.java)
                    startActivity(intent)
                }
                R.id.nav_perfil -> {
                    // Navegar a Activity3
                    drawerLayout.closeDrawers()
                }
                R.id.nav_configuracion -> {
                    // Navegar a Activity3
                    val intent = Intent(this, ConfiguracionActivity::class.java)
                    startActivity(intent)
                }
            }
            drawerLayout.closeDrawers() // Cerrar el Drawer después de seleccionar
            true
        }
    }

    // Manejar la apertura del Navigation Drawer cuando se presiona el botón de menú
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                drawerLayout.openDrawer(GravityCompat.START)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}