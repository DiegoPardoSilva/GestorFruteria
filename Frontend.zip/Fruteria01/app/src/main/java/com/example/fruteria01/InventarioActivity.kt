package com.example.fruteria01

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.example.fruteria01.fragments.ControlBdFragment
import com.example.fruteria01.fragments.ListaInventarioFragment
import com.google.android.material.navigation.NavigationView

class InventarioActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inventario)

        drawerLayout = findViewById(R.id.drawer_layout)

        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar_main)
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.navigator_menu_logo)

        val navigationView: NavigationView = findViewById(R.id.nav_view)
        navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_inventario -> {
                    drawerLayout.closeDrawers()
                }
                R.id.nav_registro_ventas -> {
                    val intent = Intent(this, RegistroVentasActivity::class.java)
                    startActivity(intent)
                }
                R.id.nav_notificaciones -> {
                    val intent = Intent(this, NotificacionesActivity::class.java)
                    startActivity(intent)
                }
                R.id.nav_perfil -> {
                    val intent = Intent(this, PerfilActivity::class.java)
                    startActivity(intent)
                }
                R.id.nav_configuracion -> {
                    val intent = Intent(this, ConfiguracionActivity::class.java)
                    startActivity(intent)
                }
            }
            drawerLayout.closeDrawers()
            true
        }

        supportFragmentManager.beginTransaction()
            .replace(R.id.content_frame, ListaInventarioFragment())
            .commit()

        val buttonFragment1: Button = findViewById(R.id.btnFragment1)
        buttonFragment1.setOnClickListener {
            supportFragmentManager.beginTransaction()
                .replace(R.id.content_frame, ListaInventarioFragment())
                .commit()
        }

        val buttonFragment2: Button = findViewById(R.id.btnFragment2)
        buttonFragment2.setOnClickListener {
            supportFragmentManager.beginTransaction()
                .replace(R.id.content_frame, ControlBdFragment())
                .commit()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                drawerLayout.openDrawer(GravityCompat.START)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
