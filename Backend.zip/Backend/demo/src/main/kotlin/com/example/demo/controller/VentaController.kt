package com.example.demo.controller

import com.example.demo.domain.Venta
import com.example.demo.service.VentaService
import org.springframework.web.bind.annotation.*
import org.springframework.http.ResponseEntity
import java.util.Optional

@RestController
@RequestMapping("/ventas")
class VentaController(val ventaService: VentaService) {

    @PostMapping
    fun crearVenta(@RequestBody venta: Venta): ResponseEntity<Venta> {
        val ventaGuardada = ventaService.crearVenta(venta)
        return ResponseEntity.ok(ventaGuardada)
    }

    @GetMapping("/{id}")
    fun obtenerVenta(@PathVariable id: Long): ResponseEntity<Optional<Venta>> {
        val venta = ventaService.obtenerVentaPorId(id)
        return ResponseEntity.ok(venta)
    }

    @GetMapping
    fun obtenerVentas(): ResponseEntity<List<Venta>> {
        val ventas = ventaService.obtenerTodasLasVentas()
        return ResponseEntity.ok(ventas)
    }

    @PutMapping("/{id}")
    fun actualizarVenta(@PathVariable id: Long, @RequestBody venta: Venta): ResponseEntity<Venta> {
        val ventaActualizada = ventaService.actualizarVenta(id, venta)
        return ResponseEntity.ok(ventaActualizada)
    }

    @DeleteMapping("/{id}")
    fun eliminarVenta(@PathVariable id: Long): ResponseEntity<Void> {
        ventaService.eliminarVenta(id)
        return ResponseEntity.noContent().build()
    }
}
