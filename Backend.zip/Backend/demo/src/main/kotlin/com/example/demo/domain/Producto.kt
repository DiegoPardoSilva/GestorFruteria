package com.example.demo.domain

import java.time.LocalDate

class Producto(
    private val id:Long,
    private var nombre:String,
    private var tipo:String,
    private var fechaCaducidad:LocalDate,
    private var precio:Double,
    private var imagenUrl: String
) {
    // Getters
    fun getId(): Long = id
    fun getNombre(): String = nombre
    fun getTipo(): String = tipo
    fun getFechaCaducidad(): LocalDate = fechaCaducidad
    fun getPrecio(): Double = precio

    // Setters
    fun setNombre(nuevoNombre: String) {
        nombre = nuevoNombre
    }

    fun setTipo(nuevoTipo: String) {
        tipo = nuevoTipo
    }

    fun setFechaCaducidad(nuevaFechaCaducidad: LocalDate) {
        fechaCaducidad = nuevaFechaCaducidad
    }

    fun setPrecio(nuevoPrecio: Double) {
        precio = nuevoPrecio
    }

    fun getImagenUrl(): String {
        return imagenUrl
    }

    fun setImagenUrl(imagenUrl: String) {
        this.imagenUrl = imagenUrl
    }
}