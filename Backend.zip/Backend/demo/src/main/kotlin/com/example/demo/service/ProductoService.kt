package com.example.demo.service

import com.example.demo.domain.Producto
import java.util.Optional

interface ProductoService {
    fun crearProducto(producto: Producto): Producto
    fun obtenerProductoPorId(id: Long): Optional<Producto>
    fun obtenerTodosLosProductos(): List<Producto>
    fun actualizarProducto(id: Long, producto: Producto): Producto
    fun eliminarProducto(id: Long)
}
