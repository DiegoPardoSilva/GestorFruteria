package com.example.demo.controller

import com.example.demo.domain.Usuario
import com.example.demo.service.UsuarioService
import com.example.demo.dto.UsuarioDTO
import org.springframework.web.bind.annotation.*
import org.springframework.http.ResponseEntity
import java.util.Optional

@RestController
@RequestMapping("/usuarios")
class UsuarioController(val usuarioService: UsuarioService) {

    @PostMapping
    fun crearUsuario(@RequestBody usuario: Usuario): ResponseEntity<Usuario> {
        val usuarioGuardado = usuarioService.crearUsuario(usuario)
        return ResponseEntity.ok(usuarioGuardado)
    }

    @GetMapping("/{id}")
    fun obtenerUsuario(@PathVariable id: Long): ResponseEntity<Optional<Usuario>> {
        val usuario = usuarioService.obtenerUsuarioPorId(id)
        return ResponseEntity.ok(usuario)
    }

    @GetMapping
    fun obtenerUsuarios(): ResponseEntity<List<Usuario>> {
        val usuarios = usuarioService.obtenerTodosLosUsuarios()
        return ResponseEntity.ok(usuarios)
    }

    @PutMapping("/{id}")
    fun actualizarUsuario(@PathVariable id: Long, @RequestBody usuario: Usuario): ResponseEntity<Usuario> {
        val usuarioActualizado = usuarioService.actualizarUsuario(id, usuario)
        return ResponseEntity.ok(usuarioActualizado)
    }

    @DeleteMapping("/{id}")
    fun eliminarUsuario(@PathVariable id: Long): ResponseEntity<Void> {
        usuarioService.eliminarUsuario(id)
        return ResponseEntity.noContent().build()
    }
}

