package com.example.demo.service
import com.example.demo.dto.VentaDTO
import com.example.demo.domain.Venta
import com.example.demo.repository.VentaRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.Optional

@Service
class VentaServiceImpl @Autowired constructor(
    private val ventaRepository: VentaRepository
) : VentaService {

    override fun crearVenta(venta: Venta): Venta {
        return ventaRepository.save(venta)
    }

    override fun obtenerVentaPorId(id: Long): Optional<Venta> {
        return ventaRepository.findById(id)
    }

    override fun obtenerTodasLasVentas(): List<Venta> {
        return ventaRepository.findAll()
    }

    override fun actualizarVenta(id: Long, venta: Venta): Venta {
        val ventaExistente = ventaRepository.findById(id).orElseThrow {
            RuntimeException("Venta no encontrada con id $id")
        }
        ventaExistente.setProductoId(venta.getProductoId())
        ventaExistente.setProveedorId(venta.getProveedorId())
        ventaExistente.setFechaVenta(venta.getFechaVenta())
        ventaExistente.setPrecio(venta.getPrecio())

        return ventaRepository.save(ventaExistente)
    }

    override fun eliminarVenta(id: Long) {
        if (!ventaRepository.existsById(id)) {
            throw RuntimeException("Venta no encontrada con id $id")
        }
        ventaRepository.deleteById(id)
    }
}
