package com.example.demo.service

import com.example.demo.domain.Compra

interface CompraService {
    fun crearCompra(compra: Compra): Compra
    fun obtenerCompraPorId(id: Long): Compra?
    fun obtenerTodasLasCompras(): List<Compra>
    fun actualizarCompra(id: Long, compra: Compra): Compra
    fun eliminarCompra(id: Long)
}
