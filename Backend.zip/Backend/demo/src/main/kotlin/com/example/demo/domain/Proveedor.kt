package com.example.demo.domain

class Proveedor(
    private val id:Long,
    private var nombre:String,
    private var telefono:Long,
    private var email:String,
    private var direccion:String
) {
    fun getId(): Long {
        return id
    }

    fun getNombre(): String {
        return nombre
    }

    fun setNombre(nuevoNombre: String) {
        nombre = nuevoNombre
    }

    fun getTelefono(): Long {
        return telefono
    }

    fun setTelefono(nuevoTelefono: Long) {
        telefono = nuevoTelefono
    }

    fun getEmail(): String {
        return email
    }

    fun setEmail(nuevoEmail: String) {
        email = nuevoEmail
    }

    fun getDireccion(): String {
        return direccion
    }

    fun setDireccion(nuevaDireccion: String) {
        direccion = nuevaDireccion
    }
}