package com.example.demo.service.impl

import com.example.demo.domain.Proveedor
import com.example.demo.repository.ProveedorRepository
import com.example.demo.service.ProveedorService
import org.springframework.stereotype.Service
import java.util.Optional

@Service
class ProveedorServiceImpl(
    private val proveedorRepository: ProveedorRepository
) : ProveedorService {

    override fun crearProveedor(proveedor: Proveedor): Proveedor {
        return proveedorRepository.save(proveedor)
    }

    override fun obtenerProveedorPorId(id: Long): Optional<Proveedor> {
        return proveedorRepository.findById(id)
    }

    override fun obtenerTodosLosProveedores(): List<Proveedor> {
        return proveedorRepository.findAll()
    }

    override fun actualizarProveedor(id: Long, proveedor: Proveedor): Proveedor {
        val proveedorExistente = proveedorRepository.findById(id).orElseThrow {
            RuntimeException("Proveedor no encontrado con id $id")
        }
        proveedorExistente.setNombre(proveedor.getNombre())
        proveedorExistente.setTelefono(proveedor.getTelefono())
        proveedorExistente.setEmail(proveedor.getEmail())
        proveedorExistente.setDireccion(proveedor.getDireccion())

        return proveedorRepository.save(proveedorExistente)
    }

    override fun eliminarProveedor(id: Long) {
        if (!proveedorRepository.existsById(id)) {
            throw RuntimeException("Proveedor no encontrado")
        }
        proveedorRepository.deleteById(id)
    }
}
