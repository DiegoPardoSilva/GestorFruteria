package com.example.demo.service.impl

import com.example.demo.domain.Producto
import com.example.demo.repository.ProductoRepository
import com.example.demo.service.ProductoService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.Optional

@Service
class ProductoServiceImpl @Autowired constructor(
    private val productoRepository: ProductoRepository
) : ProductoService {

    override fun crearProducto(producto: Producto): Producto {
        return productoRepository.save(producto)
    }

    override fun obtenerProductoPorId(id: Long): Optional<Producto> {
        return productoRepository.findById(id)
    }

    override fun obtenerTodosLosProductos(): List<Producto> {
        return productoRepository.findAll()
    }

    override fun actualizarProducto(id: Long, producto: Producto): Producto {
        val productoExistente = productoRepository.findById(id).orElseThrow {
            RuntimeException("Producto no encontrado con id $id")
        }
        productoExistente.setNombre(producto.getNombre())
        productoExistente.setTipo(producto.getTipo())
        productoExistente.setFechaCaducidad(producto.getFechaCaducidad())
        productoExistente.setPrecio(producto.getPrecio())
        productoExistente.setImagenUrl(producto.getImagenUrl())

        return productoRepository.save(productoExistente)
    }

    override fun eliminarProducto(id: Long) {
        if (!productoRepository.existsById(id)) {
            throw RuntimeException("Producto no encontrado")
        }
        productoRepository.deleteById(id)
    }
}

