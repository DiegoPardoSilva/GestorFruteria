package com.example.demo.controller

import com.example.demo.domain.Compra
import com.example.demo.service.CompraService
import org.springframework.web.bind.annotation.*
import org.springframework.http.ResponseEntity
import java.util.*

@RestController
@RequestMapping("/compras")
class CompraController(val compraService: CompraService) {

    @PostMapping
    fun crearCompra(@RequestBody compra: Compra): ResponseEntity<Compra> {
        val compraGuardada = compraService.crearCompra(compra)
        return ResponseEntity.ok(compraGuardada)
    }

    @GetMapping("/{id}")
    fun obtenerCompra(@PathVariable id: Long): ResponseEntity<Optional<Compra>> {
        val compra = compraService.obtenerCompraPorId(id)
        return ResponseEntity.ok(Optional.ofNullable(compra))
    }

    @GetMapping
    fun obtenerCompras(): ResponseEntity<List<Compra>> {
        val compras = compraService.obtenerTodasLasCompras()
        return ResponseEntity.ok(compras)
    }

    @PutMapping("/{id}")
    fun actualizarCompra(@PathVariable id: Long, @RequestBody compra: Compra): ResponseEntity<Compra> {
        val compraActualizada = compraService.actualizarCompra(id, compra)
        return ResponseEntity.ok(compraActualizada)
    }

    @DeleteMapping("/{id}")
    fun eliminarCompra(@PathVariable id: Long): ResponseEntity<Void> {
        compraService.eliminarCompra(id)
        return ResponseEntity.noContent().build()
    }
}
