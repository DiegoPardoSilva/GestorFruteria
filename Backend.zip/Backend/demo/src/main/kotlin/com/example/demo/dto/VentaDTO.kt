package com.example.demo.dto

import java.time.LocalDate

class VentaDTO(
    private val id:Long,
    private var productoId:Long,
    private var proveedorId:Long,
    private var fechaVenta:LocalDate,
    private var precioCompra:Double
) {

    fun getId(): Long {
        return id
    }

    fun getProductoId(): Long {
        return productoId
    }

    fun setProductoId(productoId: Long) {
        this.productoId = productoId
    }

    fun getProveedorId(): Long {
        return proveedorId
    }

    fun setProveedorId(proveedorId: Long) {
        this.proveedorId = proveedorId
    }

    fun getFechaVenta(): LocalDate {
        return fechaVenta
    }

    fun setFechaVenta(fechaVenta: LocalDate) {
        this.fechaVenta = fechaVenta
    }

    fun getPrecio(): Double {
        return precioCompra
    }

    fun setPrecio(precioCompra: Double) {
        this.precioCompra = precioCompra
    }
}