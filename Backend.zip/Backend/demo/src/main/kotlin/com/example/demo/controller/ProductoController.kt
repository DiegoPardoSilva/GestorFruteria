package com.example.demo.controller

import com.example.demo.domain.Producto
import com.example.demo.service.ProductoService
import org.springframework.web.bind.annotation.*
import org.springframework.http.ResponseEntity
import java.util.Optional

@RestController
@RequestMapping("/productos")
class ProductoController(val productoService: ProductoService) {

    @PostMapping
    fun crearProducto(@RequestBody producto: Producto): ResponseEntity<Producto> {
        val productoGuardado = productoService.crearProducto(producto)
        return ResponseEntity.ok(productoGuardado)
    }

    @GetMapping("/{id}")
    fun obtenerProducto(@PathVariable id: Long): ResponseEntity<Optional<Producto>> {
        val producto = productoService.obtenerProductoPorId(id)
        return ResponseEntity.ok(producto)
    }

    @GetMapping
    fun obtenerProductos(): ResponseEntity<List<Producto>> {
        val productos = productoService.obtenerTodosLosProductos()
        return ResponseEntity.ok(productos)
    }

    @PutMapping("/{id}")
    fun actualizarProducto(@PathVariable id: Long, @RequestBody producto: Producto): ResponseEntity<Producto> {
        val productoActualizado = productoService.actualizarProducto(id, producto)
        return ResponseEntity.ok(productoActualizado)
    }

    @DeleteMapping("/{id}")
    fun eliminarProducto(@PathVariable id: Long): ResponseEntity<Void> {
        productoService.eliminarProducto(id)
        return ResponseEntity.noContent().build()
    }
}
