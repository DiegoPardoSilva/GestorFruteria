package com.example.demo.service

import com.example.demo.repository.UsuarioRepository
import com.example.demo.domain.Usuario
import org.springframework.stereotype.Service
import org.springframework.beans.factory.annotation.Autowired
import java.util.Optional

@Service
class UsuarioServiceImpl @Autowired constructor(
    private val usuarioRepository: UsuarioRepository
) : UsuarioService {

    override fun crearUsuario(usuario: Usuario): Usuario {
        return usuarioRepository.save(usuario)
    }

    override fun obtenerUsuarioPorId(id: Long): Optional<Usuario> {
        return usuarioRepository.findById(id)
    }

    override fun obtenerTodosLosUsuarios(): List<Usuario> {
        return usuarioRepository.findAll()
    }

    override fun actualizarUsuario(id: Long, usuario: Usuario): Usuario {
        val usuarioExistente = usuarioRepository.findById(id).orElseThrow {
            RuntimeException("Usuario no encontrado con id $id")
        }
        usuarioExistente.setNombre(usuario.getNombre())
        usuarioExistente.setContrasena(usuario.getContrasena())  // Aquí puedes aplicar hashing si es necesario
        usuarioExistente.setNivel(usuario.getNivel())

        return usuarioRepository.save(usuarioExistente)
    }

    override fun eliminarUsuario(id: Long) {
        if (!usuarioRepository.existsById(id)) {
            throw RuntimeException("Usuario no encontrado")
        }
        usuarioRepository.deleteById(id)
    }
}