package com.example.demo.dto

class ProveedorDTO(
    private var nombre:String,
    private var telefono:Long,
    private var email:String,
    private var direccion:String
) {
}