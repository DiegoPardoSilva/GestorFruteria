package com.example.demo.controller

import com.example.demo.domain.Proveedor
import com.example.demo.service.ProveedorService
import org.springframework.web.bind.annotation.*
import org.springframework.http.ResponseEntity
import java.util.Optional

@RestController
@RequestMapping("/proveedores")
class ProveedorController(val proveedorService: ProveedorService) {

    @PostMapping
    fun crearProveedor(@RequestBody proveedor: Proveedor): ResponseEntity<Proveedor> {
        val proveedorGuardado = proveedorService.crearProveedor(proveedor)
        return ResponseEntity.ok(proveedorGuardado)
    }

    @GetMapping("/{id}")
    fun obtenerProveedor(@PathVariable id: Long): ResponseEntity<Optional<Proveedor>> {
        val proveedor = proveedorService.obtenerProveedorPorId(id)
        return ResponseEntity.ok(proveedor)
    }

    @GetMapping
    fun obtenerProveedores(): ResponseEntity<List<Proveedor>> {
        val proveedores = proveedorService.obtenerTodosLosProveedores()
        return ResponseEntity.ok(proveedores)
    }

    @PutMapping("/{id}")
    fun actualizarProveedor(@PathVariable id: Long, @RequestBody proveedor: Proveedor): ResponseEntity<Proveedor> {
        val proveedorActualizado = proveedorService.actualizarProveedor(id, proveedor)
        return ResponseEntity.ok(proveedorActualizado)
    }

    @DeleteMapping("/{id}")
    fun eliminarProveedor(@PathVariable id: Long): ResponseEntity<Void> {
        proveedorService.eliminarProveedor(id)
        return ResponseEntity.noContent().build()
    }
}
