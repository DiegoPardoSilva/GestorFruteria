package com.example.demo.domain

import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id

@Entity
data class Usuario(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private val id:Long,
    private var nombre:String,
    private var contrasena:String,
    private var nivel:Int
) {
    fun getId(): Long {
        return id
    }

    fun getNombre(): String {
        return nombre
    }

    fun setNombre(nuevoNombre: String) {
        nombre = nuevoNombre
    }

    fun getContrasena(): String {
        return contrasena
    }

    fun setContrasena(nuevaContrasena: String) {
        contrasena = nuevaContrasena
    }

    fun getNivel(): Int {
        return nivel
    }

    fun setNivel(nuevoNivel: Int) {
        nivel = nuevoNivel
    }
}