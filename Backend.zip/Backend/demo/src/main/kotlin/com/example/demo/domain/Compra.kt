package com.example.demo.domain

import java.time.LocalDate

class Compra(
    private val id: Long,
    private val idProducto: Long,
    private val idProveedor: Long,
    private var precioCompra: Double,
    private var fechaCompra: LocalDate
) {

    fun getId(): Long {
        return id
    }

    fun getIdProducto(): Long {
        return idProducto
    }

    fun getIdProveedor(): Long {
        return idProveedor
    }

    fun getPrecioCompra(): Double {
        return precioCompra
    }

    fun setPrecioCompra(nuevoPrecio: Double) {
        precioCompra = nuevoPrecio
    }

    fun getFechaCompra(): LocalDate {
        return fechaCompra
    }

    fun setFechaCompra(nuevaFecha: LocalDate) {
        fechaCompra = nuevaFecha
    }
}
