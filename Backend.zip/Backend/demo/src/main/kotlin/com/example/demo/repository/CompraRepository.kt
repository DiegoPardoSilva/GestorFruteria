package com.example.demo.repository

import com.example.demo.domain.Compra
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface CompraRepository : JpaRepository<Compra, Long> {
    // Métodos adicionales si es necesario
}
