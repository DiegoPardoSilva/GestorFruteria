package com.example.demo.dto

data class UsuarioDTO(
    private val id: Long,
    private var nombre: String,
    private var contrasena: String,
    private var nivel: Int
) {
    // Constructor secundario sin la contraseña
    constructor(id: Long, nombre: String, nivel: Int) : this(id, nombre, "", nivel)

    // Getters y setters
    fun getId(): Long {
        return id
    }

    fun getNombre(): String {
        return nombre
    }

    fun setNombre(nuevoNombre: String) {
        nombre = nuevoNombre
    }

    fun getContrasena(): String {
        return contrasena
    }

    fun setContrasena(nuevaContrasena: String) {
        contrasena = nuevaContrasena
    }

    fun getNivel(): Int {
        return nivel
    }

    fun setNivel(nuevoNivel: Int) {
        nivel = nuevoNivel
    }
}
