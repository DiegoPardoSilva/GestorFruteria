package com.example.demo.service

import com.example.demo.domain.Proveedor
import java.util.Optional

interface ProveedorService {
    fun crearProveedor(proveedor: Proveedor): Proveedor
    fun obtenerProveedorPorId(id: Long): Optional<Proveedor>
    fun obtenerTodosLosProveedores(): List<Proveedor>
    fun actualizarProveedor(id: Long, proveedor: Proveedor): Proveedor
    fun eliminarProveedor(id: Long)
}
