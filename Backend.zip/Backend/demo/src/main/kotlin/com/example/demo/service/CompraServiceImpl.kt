package com.example.demo.service.impl

import com.example.demo.domain.Compra
import com.example.demo.repository.CompraRepository
import com.example.demo.service.CompraService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*

@Service
class CompraServiceImpl @Autowired constructor(
    private val compraRepository: CompraRepository
) : CompraService {

    override fun crearCompra(compra: Compra): Compra {
        return compraRepository.save(compra)
    }

    override fun obtenerCompraPorId(id: Long): Compra? {
        return compraRepository.findById(id).orElse(null)
    }

    override fun obtenerTodasLasCompras(): List<Compra> {
        return compraRepository.findAll()
    }

    override fun actualizarCompra(id: Long, compra: Compra): Compra {
        val compraExistente = compraRepository.findById(id).orElseThrow {
            RuntimeException("Compra no encontrada con id $id")
        }

        compraExistente.setPrecioCompra(compra.getPrecioCompra())
        compraExistente.setFechaCompra(compra.getFechaCompra())

        return compraRepository.save(compraExistente)
    }

    override fun eliminarCompra(id: Long) {
        if (!compraRepository.existsById(id)) {
            throw RuntimeException("Compra no encontrada")
        }
        compraRepository.deleteById(id)
    }
}
