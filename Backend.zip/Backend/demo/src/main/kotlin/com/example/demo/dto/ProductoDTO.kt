package com.example.demo.dto

import java.time.LocalDate

class ProductoDTO(
    private var nombre:String,
    private var tipo:String,
    private var fechaCaducidad:LocalDate,
    private var precio:Double
) {
}