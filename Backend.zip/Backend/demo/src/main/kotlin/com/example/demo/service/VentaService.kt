package com.example.demo.service

import com.example.demo.domain.Venta
import com.example.demo.dto.VentaDTO
import java.util.Optional

interface VentaService {
    fun crearVenta(ventaDTO: Venta): Venta
    fun obtenerVentaPorId(id: Long): Optional<Venta>
    fun obtenerTodasLasVentas(): List<Venta>
    fun actualizarVenta(id: Long, ventaDTO: Venta): Venta
    fun eliminarVenta(id: Long)
}
