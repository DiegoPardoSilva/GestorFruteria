package com.example.demo.service

import com.example.demo.domain.Usuario
import java.util.Optional


interface UsuarioService {
    fun crearUsuario(usuario: Usuario): Usuario
    fun obtenerUsuarioPorId(id: Long): Optional<Usuario>
    fun obtenerTodosLosUsuarios(): List<Usuario>
    fun actualizarUsuario(id: Long, usuario: Usuario): Usuario
    fun eliminarUsuario(id: Long)
}