package com.example.fruteria01

import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navController: NavController
    private lateinit var appBarConfiguration: AppBarConfiguration

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawerLayout = findViewById(R.id.drawer_layout)

        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar_main)
        setSupportActionBar(toolbar)

        // Configurar el NavController y NavHostFragment
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController

        // Configurar AppBarConfiguration con el DrawerLayout
        appBarConfiguration = AppBarConfiguration(navController.graph, drawerLayout)

        // Vincular la toolbar con NavController
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration)

        // Configurar la NavigationView con el NavController
        val navigationView: NavigationView = findViewById(R.id.nav_view)
        NavigationUI.setupWithNavController(navigationView, navController)
    }

    override fun onSupportNavigateUp(): Boolean {
        return NavigationUI.navigateUp(navController, appBarConfiguration) || super.onSupportNavigateUp()
    }
    //NO FUNCIONA TODAVÍA
    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        Toast.makeText(this, "opcion seleccionada", Toast.LENGTH_SHORT).show()
        Log.d("Navigation", "Item seleccionado: ${item.title}")
        when (item.itemId) {
            R.id.nav_inventario -> navController.navigate(R.id.fragmentInventario)
            R.id.nav_registro_ventas -> navController.navigate(R.id.fragmentVentas)
            R.id.nav_entrada_productos -> navController.navigate(R.id.fragmentProveedores)
            R.id.nav_notificaciones -> navController.navigate(R.id.fragmentNotificaciones)
            R.id.nav_perfil -> navController.navigate(R.id.fragmentPerfil)
            R.id.nav_configuracion -> navController.navigate(R.id.fragmentConfiguracion)
        }
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }
}
