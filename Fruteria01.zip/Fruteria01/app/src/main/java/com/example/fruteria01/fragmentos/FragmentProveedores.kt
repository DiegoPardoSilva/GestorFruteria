package com.example.fruteria01.fragmentos

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import com.example.fruteria01.R

class FragmentProveedores : Fragment(R.layout.fragment_proveedores) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }
}